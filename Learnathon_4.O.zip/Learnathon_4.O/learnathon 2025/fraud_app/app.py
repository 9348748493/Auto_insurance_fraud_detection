from flask import Flask, render_template, request, send_file
import pandas as pd
import pickle
import os

app = Flask(__name__)
UPLOAD_FOLDER = 'uploads'
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

# Load trained model and feature columns
model = pickle.load(open('model.pkl', 'rb'))
columns = pickle.load(open('columns.pkl', 'rb'))

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    file = request.files['file']
    file_path = os.path.join(UPLOAD_FOLDER, file.filename)
    file.save(file_path)

    # Load and preprocess data
    data = pd.read_csv(file_path)
    drop_cols = ['Claim_ID', 'Bind_Date1', 'Policy_Num', 'Policy_Start_Date',
                 'Policy_Expiry_Date', 'Accident_Date', 'Claims_Date',
                 'DL_Expiry_Date', 'Vehicle_Registration']
    if 'Fraud_Ind' in data.columns:
        data = data.drop(columns=['Fraud_Ind'])
    data = data.drop(columns=[col for col in drop_cols if col in data.columns])
    data = pd.get_dummies(data, drop_first=True)
    data = data.reindex(columns=columns, fill_value=0)

    # Predict
    predictions = model.predict(data)
    result = pd.read_csv(file_path)
    result['Predicted_Fraud'] = predictions

    result_path = os.path.join(UPLOAD_FOLDER, 'result.csv')
    result.to_csv(result_path, index=False)

    fraud = int((predictions == 1).sum())
    genuine = int((predictions == 0).sum())

    return render_template('index.html', fraud=fraud, genuine=genuine, file_download=result_path)

@app.route('/download')
def download():
    return send_file(os.path.join(UPLOAD_FOLDER, 'result.csv'), as_attachment=True)

if __name__ == '__main__':
    app.run(debug=True)